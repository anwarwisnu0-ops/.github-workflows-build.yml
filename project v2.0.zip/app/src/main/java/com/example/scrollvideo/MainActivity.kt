package com.example.scrollvideo

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var diag: TextView
    private lateinit var chargeStatus: TextView
    private lateinit var lowStatus: TextView
    private val bg = Color.parseColor("#0F1115")
    private val cardColor = Color.parseColor("#1A1D24")
    private val accent = Color.parseColor("#7C5CFF")
    private val muted = Color.parseColor("#9AA0AE")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun label(t: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun cardOf(title: String, vararg views: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(cardColor, 18)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        c.addView(label(title, 13f, accent, true))
        views.forEach { v ->
            c.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        }
        return c
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = box(if (primary) accent else Color.parseColor("#2A2E38"), 12)
        setOnClickListener { onClick() }
    }

    private fun toggle(t: String, key: String, def: Boolean = false) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE)
        isChecked = prefs.getBoolean(key, def)
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun field(title: String, v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 13f, muted))
        addView(v)
    }

    private fun numField(hint: String, key: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        this.hint = hint
        setHintTextColor(muted); setTextColor(Color.WHITE)
        setText(prefs.getInt(key, 0).let { if (it == 0) "" else it.toString() })
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putInt(key, s.toString().toIntOrNull() ?: 0).apply()
            }
        })
    }

    private fun readList() =
        (prefs.getString("videos", null) ?: prefs.getString("video", null) ?: "")
            .split("\n").filter { it.isNotBlank() }

    private fun pickVideos(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    private fun pickSingle(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    private fun specialRow(key: String, code: Int, statusView: TextView): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Pilih video", false) { pickSingle(code) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(button("Hapus", false) { prefs.edit().remove(key).apply(); refresh() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(statusView)
            addView(row)
        }
    }

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, VideoWallpaperService::class.java)
        )
        try { startActivity(i) } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        status = label("", 17f, Color.WHITE, true)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Pilih video", false) { pickVideos(1) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(button("Tambah video", false) { pickVideos(2) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }

        val intervals = listOf(0, -1, 5, 15, 30, 60)
        val intervalSpin = spinner(
            listOf("Tidak ganti (ulang video yang sama)", "Tiap kembali ke layar utama",
                "Tiap 5 menit", "Tiap 15 menit", "Tiap 30 menit", "Tiap 1 jam"),
            intervals.indexOf(prefs.getInt("interval", 0)).coerceAtLeast(0)
        ) { prefs.edit().putInt("interval", intervals[it]).apply() }

        val engines = listOf(1, 0)
        val engineSpin = spinner(
            listOf("ExoPlayer (baru, lebih mulus)", "Bawaan Android (lama)"),
            engines.indexOf(prefs.getInt("engine", 1)).coerceAtLeast(0)
        ) { prefs.edit().putInt("engine", engines[it]).apply() }

        val speeds = listOf(0.5f, 0.75f, 1f, 1.5f, 2f)
        val speedSpin = spinner(
            listOf("0.5x (lambat)", "0.75x", "1x (normal)", "1.5x", "2x (cepat)"),
            speeds.indexOf(prefs.getFloat("speed", 1f)).let { if (it < 0) 2 else it }
        ) { prefs.edit().putFloat("speed", speeds[it]).apply() }

        val dimLabel = label("Gelapkan video: ${prefs.getInt("dim", 0)}%", 13f, muted)
        val dimSeek = SeekBar(this).apply {
            max = 80; progress = prefs.getInt("dim", 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    dimLabel.text = "Gelapkan video: $p%"
                    if (fromUser) prefs.edit().putInt("dim", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val panLabel = label("Kekuatan geser: ${prefs.getInt("pan_strength", 100)}%", 13f, muted)
        val panSeek = SeekBar(this).apply {
            max = 80; progress = prefs.getInt("pan_strength", 100) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    panLabel.text = "Kekuatan geser: ${p + 20}%"
                    if (fromUser) prefs.edit().putInt("pan_strength", p + 20).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val gyroLabel = label("Gyro parallax: ${prefs.getInt("gyro", 0)}% (0 = mati)", 13f, muted)
        val gyroSeek = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("gyro", 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    gyroLabel.text = "Gyro parallax: $p% (0 = mati)"
                    if (fromUser) prefs.edit().putInt("gyro", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val trimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(numField("Mulai (detik)", "trim_start"),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(numField("Selesai (0 = akhir)", "trim_end"),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }

        val bats = listOf(0, 15, 20, 30, 50)
        val batSpin = spinner(
            listOf("Mati", "Di bawah 15%", "Di bawah 20%", "Di bawah 30%", "Di bawah 50%"),
            bats.indexOf(prefs.getInt("bat_min", 0)).coerceAtLeast(0)
        ) { prefs.edit().putInt("bat_min", bats[it]).apply() }

        val lites = listOf(0, 1, 2, 3)
        val liteSpin = spinner(
            listOf("Mati (fps mengikuti video)", "Ringan • batasi 30fps",
                "Hemat • batasi 24fps", "Sangat hemat • batasi 20fps"),
            prefs.getInt("lite", 1).coerceIn(0, 3)
        ) { prefs.edit().putInt("lite", lites[it]).apply() }

        val heats = listOf(0, 40, 43, 45)
        val heatSpin = spinner(
            listOf("Mati", "Jeda di 40°C", "Jeda di 43°C", "Jeda di 45°C"),
            heats.indexOf(prefs.getInt("heat_max", 45)).coerceAtLeast(0)
        ) { prefs.edit().putInt("heat_max", heats[it]).apply() }

        val lows = listOf(10, 15, 20, 30)
        val lowSpin = spinner(
            listOf("Baterai rendah: 10%", "Baterai rendah: 15%", "Baterai rendah: 20%", "Baterai rendah: 30%"),
            lows.indexOf(prefs.getInt("low_pct", 20)).coerceAtLeast(0)
        ) { prefs.edit().putInt("low_pct", lows[it]).apply() }

        chargeStatus = label("", 13f, Color.WHITE)
        lowStatus = label("", 13f, Color.WHITE)

        diag = label("", 13f, Color.WHITE)
        val diagRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Segarkan", false) { refreshDiag() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(button("Reset", false) { prefs.edit().putString("dbg", "").remove("last_err").remove("stall").remove("pause_stats").apply(); refreshDiag() },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        root.addView(label("Scroll Video Wallpaper", 26f, Color.WHITE, true))
        root.addView(label("v2.0 • Video landscape jadi wallpaper yang ikut bergeser", 14f, muted),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4); bottomMargin = dp(8) })
        val cards = listOf(
            cardOf("VIDEO", status, row, button("Pasang sebagai wallpaper", true) { applyWallpaper() }),
            cardOf("PLAYLIST", field("Ganti video otomatis", intervalSpin)),
            cardOf("PEMUTARAN",
                toggle("Suara video", "sound"),
                field("Mesin pemutar", engineSpin),
                toggle("Loop mulus tanpa jeda", "gapless", true),
                toggle("Geser otomatis (tanpa perlu scroll)", "auto_pan"),
                field("Kecepatan", speedSpin),
                dimLabel, dimSeek, panLabel, panSeek, gyroLabel, gyroSeek,
                toggle("Balik arah gyro", "gyro_inv"),
                label("Potong bagian video yang diulang", 13f, muted), trimRow),
            cardOf("HEMAT & ANTI PANAS",
                field("Mode ringan (batasi fps)", liteSpin),
                toggle("Jeda saat aplikasi lain dibuka", "pause_hidden", true),
                field("Berhenti otomatis kalau baterai", batSpin),
                field("Pelindung panas (suhu baterai)", heatSpin),
                toggle("Redupkan otomatis di ruangan gelap", "auto_dim"),
                label("Layar mati selalu menjeda video. Mode hemat daya sistem juga ikut menjeda saat opsi baterai aktif.", 12f, muted)),
            cardOf("VIDEO SESUAI BATERAI",
                label("Video saat mengisi daya", 13f, muted),
                specialRow("video_charge", 3, chargeStatus),
                label("Video saat baterai rendah (tenang)", 13f, muted),
                specialRow("video_low", 4, lowStatus),
                lowSpin),
            cardOf("DIAGNOSA GESER", diag, diagRow,
                label("Geser halaman layar utama, buka aplikasi ini lagi, lalu ketuk Segarkan.", 12f, muted))
        )
        cards.forEach { root.addView(it, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }) }

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
        refresh()
        refreshDiag()
    }

    override fun onResume() {
        super.onResume()
        refreshDiag()
    }

    private fun refreshDiag() {
        val p = (prefs.getString("dbg", "") ?: "").split(",")
        val err = prefs.getString("last_err", null)
        val st = prefs.getString("stall", null)?.split(",")
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tNow = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lNow = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val ps = prefs.getString("pause_stats", null)?.split(",", limit = 5)
        val extra = "\nSuhu baterai sekarang: " + String.format(java.util.Locale.US, "%.1f", tNow) + "C, level " + lNow + "%" +
            (if (ps != null && ps.size >= 4) "\nJeda: layar mati ${ps[0]}x, app lain ${ps[1]}x, baterai ${ps[2]}x, panas ${ps[3]}x" +
                (if (ps.size > 4 && ps[4].isNotBlank()) " (terakhir: ${ps[4]})" else "") else "\nJeda: belum ada")
        diag.text = (if (p.size < 5) "Belum ada data geser dari launcher."
        else "Data geser diterima: ${p[0]} kali\nTerakhir: ${p[1]} (rentang ${p[2]} sampai ${p[3]})\nLangkah per halaman: ${p[4]}") + (if (st == null || st.size < 2) "\nJeda frame: belum ada yang lebih dari 150 ms" else "\nJeda frame terpanjang: ${st[0]} ms (${st[1]}x lebih dari 150 ms)" + (if (st.size > 2) "\nDipulihkan otomatis: ${st[2]}x" else "") + (if (st.size > 3) "\nLoop dipaksa: ${st[3]}x" else "")) + extra + (if (err == null) "" else "\nError terakhir: $err")
    }

    private fun refresh() {
        val n = readList().size
        status.text = if (n == 0) "Belum ada video dipilih" else "$n video dipilih"
        chargeStatus.text = if (prefs.getString("video_charge", null) == null) "Belum dipilih (pakai playlist biasa)" else "Sudah dipilih"
        lowStatus.text = if (prefs.getString("video_low", null) == null) "Belum dipilih (pakai playlist biasa)" else "Sudah dipilih"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 3 || requestCode == 4) && resultCode == RESULT_OK && data?.data != null) {
            val u = data.data!!
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString(if (requestCode == 3) "video_charge" else "video_low", u.toString()).apply()
            refresh()
            return
        }
        if ((requestCode != 1 && requestCode != 2) || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        uris.forEach {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        val old = if (requestCode == 2) readList() else emptyList()
        val all = (old + uris.map { it.toString() }).distinct().joinToString("\n")
        prefs.edit().putString("videos", all).apply()
        refresh()
    }
}
