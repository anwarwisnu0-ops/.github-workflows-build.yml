package com.example.scrollvideo

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

// Pengendali ExoPlayer. Semua fungsi dipanggil dari thread utama.
class ExoCtl(
    private val ctx: Context,
    private val onError: (String) -> Unit,
    private val onAspect: (Float) -> Unit
) {
    private var player: ExoPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var cfg: Cfg? = null
    private var play = false
    private val handler = Handler(Looper.getMainLooper())

    private fun ensure(): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(ctx).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                onError("exo: " + error.errorCodeName + " " + error.message)
                handler.postDelayed({ reload() }, 1500)
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    onAspect(videoSize.width.toFloat() / videoSize.height)
                }
            }
        })
        p.setVideoSurface(surface)
        player = p
        return p
    }

    fun setSurface(s: Surface?) {
        surface = s
        try { player?.setVideoSurface(s) } catch (t: Throwable) { onError("exo surface: $t") }
    }

    fun setPlay(p: Boolean) {
        play = p
        try { player?.playWhenReady = p } catch (t: Throwable) { onError("exo play: $t") }
    }

    fun load(u: Uri, c: Cfg) {
        uri = u
        cfg = c
        reload()
    }

    private fun applyTracks(p: ExoPlayer, c: Cfg) {
        // Saat suara mati, trek audio dimatikan: pengulangan mengikuti panjang gambar saja.
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, !c.sound)
            .build()
        p.volume = if (c.sound) 1f else 0f
        p.setPlaybackSpeed(c.speed)
    }

    fun reload() {
        val u = uri ?: return
        val c = cfg ?: return
        try {
            val p = ensure()
            val b = MediaItem.Builder().setUri(u)
            if (c.trimStart > 0 || c.trimEnd > 0) {
                val cc = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.trimStart * 1000L)
                if (c.trimEnd > 0) cc.setEndPositionMs(c.trimEnd * 1000L)
                b.setClippingConfiguration(cc.build())
            }
            val item = b.build()
            // Dua item sama berurutan + ulang semua = pergantian tanpa jeda.
            p.setMediaItems(if (c.gapless) listOf(item, item) else listOf(item))
            p.repeatMode = if (c.gapless) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_ONE
            applyTracks(p, c)
            p.prepare()
            p.playWhenReady = play
        } catch (t: Throwable) {
            onError("exo load: $t")
        }
    }

    fun apply(c: Cfg) {
        val old = cfg
        cfg = c
        val p = player ?: return
        try {
            if (old == null || old.trimStart != c.trimStart || old.trimEnd != c.trimEnd || old.gapless != c.gapless) {
                reload()
            } else {
                applyTracks(p, c)
            }
        } catch (t: Throwable) {
            onError("exo apply: $t")
        }
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        try { player?.release() } catch (_: Throwable) {}
        player = null
    }
}
