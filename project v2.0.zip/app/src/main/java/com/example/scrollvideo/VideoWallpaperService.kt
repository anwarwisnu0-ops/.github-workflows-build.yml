package com.example.scrollvideo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

data class Cfg(
    val sound: Boolean, val speed: Float, val autoPan: Boolean,
    val dim: Int, val trimStart: Int, val trimEnd: Int, val panStrength: Int,
    val gapless: Boolean, val fpsCap: Int
)

class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {
        private var thread: GlThread? = null
        private var holder: SurfaceHolder? = null
        private var w = 0
        private var h = 0
        private var fullW = 0
        private var fullH = 0
        private var reqW = -1
        private var reqH = -1
        private var fixedActive = false
        private var offset = 0.5f
        private var visible = false
        private var videos: List<Uri> = emptyList()
        private var index = 0
        private var mode = 0 // 0 normal, 1 mengisi daya, 2 baterai rendah
        private var hot = false
        private var lastPlay = true
        private var cScreen = 0
        private var cHidden = 0
        private var cBatt = 0
        private var cHeat = 0
        private var lastInfo = ""
        private var exo: ExoCtl? = null
        private var surfaceGen = 0
        private var lastAspect = 0f
        private var sensorOn = false
        private var accOn = false
        private var tiltF = 0f
        private var lastTilt = 0f
        private var lastAutoDim = 0
        private var dbgN = 0
        private var dbgMin = 2f
        private var dbgMax = -1f
        private var dbgLast = 0f
        private var dbgStep = 0f
        private var dbgAt = 0L
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPref(key) }
        private val power = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { safe("rcv") { refreshAll() } }
        }
        private val ticker = object : Runnable {
            override fun run() { nextVideo(); schedule() }
        }
        private val lightListener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val lux = e.values[0]
                val p = when {
                    lux >= 60f -> 0
                    lux <= 3f -> 40
                    else -> ((60f - lux) / 57f * 40f).toInt()
                }
                if (abs(p - lastAutoDim) >= 3) { lastAutoDim = p; thread?.setAutoDim(p) }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }

        private val accListener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val amp = prefs.getInt("gyro", 0) / 100f * 0.25f
                var t = (e.values[0] / 9.81f).coerceIn(-1f, 1f)
                if (!prefs.getBoolean("gyro_inv", false)) t = -t
                tiltF += (t - tiltF) * 0.25f
                val v = (if (abs(tiltF) < 0.03f) 0f else tiltF) * amp
                lastTilt = v
                thread?.setTilt(v)
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }

        private fun report(where: String, t: Throwable) {
            android.util.Log.e("VideoWallpaper", where, t)
            try { prefs.edit().putString("last_err", where + ": " + t + " @ " + t.stackTrace.firstOrNull()).apply() } catch (_: Throwable) {}
        }

        private fun safe(where: String, block: () -> Unit) {
            try { block() } catch (t: Throwable) { report(where, t) }
        }

        private fun flushDbg() {
            if (dbgN == 0) return
            prefs.edit().putString("dbg", String.format(java.util.Locale.US, "%d,%.3f,%.3f,%.3f,%.3f", dbgN, dbgLast, dbgMin, dbgMax, dbgStep)).apply()
        }

        private fun onPref(key: String?) = safe("pref") {
            when (key) {
                "last_err", "stall", "pause_stats" -> {}
                "gyro" -> updateSensor()
                "videos" -> { loadList(); restart() }
                "video_charge", "video_low", "low_pct" -> {
                    val old = mode
                    mode = computeMode()
                    if (mode != old || mode != 0) currentUri()?.let { playUri(it) }
                }
                "dbg" -> if (prefs.getString("dbg", "").isNullOrEmpty()) { dbgN = 0; dbgMin = 2f; dbgMax = -1f; cScreen = 0; cHidden = 0; cBatt = 0; cHeat = 0; lastInfo = "" }
                "gapless", "engine" -> restart()
                "lite" -> { val c = readCfg(); thread?.setCfg(c); exo?.apply(c) }
                "interval" -> schedule()
                "pause_hidden", "bat_min", "heat_max" -> refreshPlay()
                "auto_dim" -> updateSensor()
                else -> { val c = readCfg(); thread?.setCfg(c); exo?.apply(c) }
            }
        }

        private fun useExo() = prefs.getInt("engine", 1) == 1

        private fun playUri(u: Uri) {
            thread?.setNext(u)
            if (useExo()) exo?.load(u, readCfg())
        }

        private fun ctl(): ExoCtl = exo ?: ExoCtl(applicationContext,
            { msg -> try { prefs.edit().putString("last_err", msg).apply() } catch (_: Throwable) {} },
            { a -> lastAspect = a; thread?.setAspect(a) }
        ).also { exo = it }

        private fun liteLevel() = prefs.getInt("lite", 1)
        private fun liteScale() = when (liteLevel()) { 0 -> 1f; 1 -> 1f; 2 -> 0.7f; else -> 0.5f }
        private fun fpsCap() = when (liteLevel()) { 0 -> 0; 1 -> 30; 2 -> 24; else -> 20 }

        private fun readCfg() = Cfg(
            prefs.getBoolean("sound", false), prefs.getFloat("speed", 1f),
            prefs.getBoolean("auto_pan", false), prefs.getInt("dim", 0),
            prefs.getInt("trim_start", 0), prefs.getInt("trim_end", 0),
            prefs.getInt("pan_strength", 100),
            prefs.getBoolean("gapless", true),
            fpsCap()
        )

        private fun loadList() {
            val raw = prefs.getString("videos", null) ?: prefs.getString("video", null) ?: ""
            videos = raw.split("\n").filter { it.isNotBlank() }.map { Uri.parse(it) }
            index = 0
        }

        private fun batt(): Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        private fun levelOf(i: Intent): Int {
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            return i.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) * 100 / scale
        }

        private fun batteryOk(): Boolean {
            val min = prefs.getInt("bat_min", 0)
            if (min == 0) return true
            val pm = getSystemService(PowerManager::class.java)
            if (pm != null && pm.isPowerSaveMode) return false
            val i = batt() ?: return true
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            return plugged || levelOf(i) >= min
        }

        private fun heatOk(): Boolean {
            val max = prefs.getInt("heat_max", 45)
            if (max == 0) { hot = false; return true }
            val i = batt() ?: return true
            val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            if (!hot && t >= max) hot = true
            else if (hot && t < max - 2) hot = false
            return !hot
        }

        private fun computeMode(): Int {
            val i = batt() ?: return 0
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            if (plugged && prefs.getString("video_charge", null) != null) return 1
            if (!plugged && prefs.getString("video_low", null) != null &&
                levelOf(i) <= prefs.getInt("low_pct", 20)) return 2
            return 0
        }

        private fun currentUri(): Uri? {
            val special = when (mode) {
                1 -> prefs.getString("video_charge", null)
                2 -> prefs.getString("video_low", null)
                else -> null
            }
            if (!special.isNullOrBlank()) return Uri.parse(special)
            return videos.getOrNull(index)
        }

        private fun screenOn() = getSystemService(PowerManager::class.java)?.isInteractive ?: true
        private fun shouldPlay() = screenOn() &&
            (visible || !prefs.getBoolean("pause_hidden", true)) && batteryOk() && heatOk()

        private fun refreshPlay() {
            val sOn = screenOn()
            val vis = visible || !prefs.getBoolean("pause_hidden", true)
            val bOk = batteryOk()
            val hOk = heatOk()
            val play = sOn && vis && bOk && hOk
            if (!play && lastPlay) {
                val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
                val i = batt()
                when {
                    !sOn -> cScreen++
                    !vis -> cHidden++
                    !bOk -> { cBatt++; lastInfo = "baterai $now " + (if (i != null) levelOf(i) else -1) + "%" }
                    else -> {
                        cHeat++
                        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                        lastInfo = "panas $now " + String.format(java.util.Locale.US, "%.1f", t) + "C"
                    }
                }
                try { prefs.edit().putString("pause_stats", "$cScreen,$cHidden,$cBatt,$cHeat,$lastInfo").apply() } catch (_: Throwable) {}
            }
            lastPlay = play
            thread?.setPlaying(play)
            exo?.setPlay(play)
        }

        private fun refreshMode() {
            val m = computeMode()
            if (m != mode) { mode = m; currentUri()?.let { playUri(it) } }
        }

        private fun refreshAll() { refreshMode(); refreshPlay(); updateSensor() }

        private fun updateSensor() {
            val mgr = getSystemService(SensorManager::class.java) ?: return
            val vis = visible && screenOn()
            val wantLight = vis && prefs.getBoolean("auto_dim", false)
            val wantAcc = vis && prefs.getInt("gyro", 0) > 0
            if (wantLight && !sensorOn) {
                val s = mgr.getDefaultSensor(Sensor.TYPE_LIGHT)
                if (s != null) { mgr.registerListener(lightListener, s, 1_000_000); sensorOn = true }
            } else if (!wantLight && sensorOn) {
                mgr.unregisterListener(lightListener)
                sensorOn = false
                lastAutoDim = 0
                thread?.setAutoDim(0)
            }
            if (wantAcc && !accOn) {
                val s = mgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (s != null) { mgr.registerListener(accListener, s, 50_000); accOn = true }
            } else if (!wantAcc && accOn) {
                mgr.unregisterListener(accListener)
                accOn = false
                tiltF = 0f
                lastTilt = 0f
                thread?.setTilt(0f)
            }
        }

        private fun schedule() {
            handler.removeCallbacks(ticker)
            val m = prefs.getInt("interval", 0)
            if (m > 0) handler.postDelayed(ticker, m * 60_000L)
        }

        private fun nextVideo() {
            if (mode != 0 || videos.size < 2) return
            index = (index + 1) % videos.size
            playUri(videos[index])
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(listener)
            loadList()
            mode = computeMode()
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(power, f)
            schedule()
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            handler.removeCallbacks(ticker)
            try { unregisterReceiver(power) } catch (_: Exception) {}
            getSystemService(SensorManager::class.java)?.let {
                it.unregisterListener(lightListener)
                it.unregisterListener(accListener)
            }
            sensorOn = false
            accOn = false
            stopThread()
            exo?.release()
            exo = null
            super.onDestroy()
        }

        private fun applySize(reset: Boolean) { restart() }

        override fun onSurfaceChanged(sh: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(sh, format, width, height)
            safe("surface") {
                val same = thread != null && width == w && height == h
                holder = sh; w = width; h = height
                if (!fixedActive) { fullW = width; fullH = height }
                if (!same) applySize(false)
            }
        }

        override fun onSurfaceDestroyed(sh: SurfaceHolder) {
            stopThread()
            holder = null
            super.onSurfaceDestroyed(sh)
        }

        override fun onVisibilityChanged(v: Boolean) {
            safe("vis") {
                val was = visible
                visible = v
                if (!v) flushDbg()
                if (v && !was && prefs.getInt("interval", 0) == -1) nextVideo()
                refreshAll()
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int
        ) {
            offset = xOffset
            safe("offs") { dbgOffsets(xOffset, xStep) }
            thread?.setOffset(xOffset)
        }

        private fun dbgOffsets(xOffset: Float, xStep: Float) {
            dbgN++; dbgLast = xOffset; dbgStep = xStep
            if (xOffset < dbgMin) dbgMin = xOffset
            if (xOffset > dbgMax) dbgMax = xOffset
            val now = SystemClock.uptimeMillis()
            if (now - dbgAt > 500) { dbgAt = now; flushDbg() }
        }

        private fun stopThread() {
            surfaceGen++
            exo?.setPlay(false)
            exo?.setSurface(null)
            thread?.let { it.finish(); try { it.join(1500) } catch (_: Exception) {} }
            thread = null
        }

        private fun restart() {
            stopThread()
            val sh = holder ?: return
            val u = currentUri() ?: return
            val exoMode = useExo()
            val gen = ++surfaceGen
            thread = GlThread(applicationContext, sh, w, h, u, readCfg(), offset,
                { msg -> try { prefs.edit().putString("last_err", msg).apply() } catch (_: Throwable) {} },
                { st -> try { prefs.edit().putString("stall", st).apply() } catch (_: Throwable) {} },
                exoMode,
                { surf -> handler.post { if (gen == surfaceGen) exo?.setSurface(surf) } }
            ).also {
                it.setAutoDim(lastAutoDim)
                it.setTilt(lastTilt)
                if (lastAspect > 0f) it.setAspect(lastAspect)
                val play = shouldPlay()
                it.setPlaying(play)
                it.start()
                if (exoMode) {
                    val c = ctl()
                    c.setPlay(play)
                    c.load(u, readCfg())
                } else {
                    exo?.release()
                    exo = null
                }
            }
        }
    }

    private class Slot(val tex: Int, val st: SurfaceTexture, val surf: Surface) {
        val frame = AtomicBoolean(false)
        val m = FloatArray(16)
        var has = false
        var player: MediaPlayer? = null
        var speed = -1f
        var ts = -1L
    }

    private class GlThread(
        val ctx: Context, val holder: SurfaceHolder, val sw: Int, val sh: Int,
        firstUri: Uri, startCfg: Cfg, startOffset: Float, val onError: (String) -> Unit,
        val onStat: (String) -> Unit,
        val useExo: Boolean, val onSurface: (Surface) -> Unit
    ) : Thread("video-wallpaper-gl") {
        private val queue = LinkedBlockingQueue<Int>().also { it.offer(1) }
        private val pl = Any()
        @Volatile private var running = true
        @Volatile private var dirty = false
        @Volatile private var offset = startOffset
        @Volatile private var cfg = startCfg
        @Volatile private var play = false
        @Volatile private var pending: Uri? = if (useExo) null else firstUri
        @Volatile private var extAspect = 0f
        @Volatile private var act = 0
        @Volatile private var autoDim = 0
        @Volatile private var tilt = 0f
        private var s0: Slot? = null
        private var s1: Slot? = null
        private var drawIdx = 0
        private var durMs = 0
        private var vAspect = 16f / 9f
        private var cur = startOffset
        private var lastNs = System.nanoTime()
        private var lastFrameMs = 0L
        private var curUri: Uri? = null
        private var loadedAtMs = 0L
        private var lastIterMs = 0L
        private var lastRecoverMs = 0L
        private var recoverN = 0
        private var wasPlay = false
        private var containerMs = 0
        private var videoShort = false
        private var lastSoftMs = 0L
        private var softN = 0
        private var stallN = 0
        private var stallMax = 0L
        private var lastPosNs = 0L

        private fun slot(i: Int): Slot = (if (i == 0) s0 else s1)!!
        private fun targetOffset() =
            (0.5f + (offset.coerceIn(0f, 1f) - 0.5f) * (cfg.panStrength / 100f) + tilt).coerceIn(0f, 1f)

        fun setOffset(o: Float) { offset = o; queue.offer(1) }
        fun setPlaying(p: Boolean) { if (p == play) return; play = p; dirty = true; queue.offer(1) }
        fun setCfg(c: Cfg) { cfg = c; dirty = true; queue.offer(1) }
        fun setNext(u: Uri) { if (!useExo) { pending = u; queue.offer(1) } }
        fun setAspect(a: Float) { extAspect = a; queue.offer(1) }
        fun setAutoDim(p: Int) { autoDim = p; queue.offer(1) }
        fun setTilt(t: Float) { tilt = t; queue.offer(1) }
        fun finish() { running = false; queue.offer(1) }

        private fun buf(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(a); position(0) }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
            return s
        }

        private fun newSlot(): Slot {
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            val st = SurfaceTexture(ids[0])
            val sl = Slot(ids[0], st, Surface(st))
            st.setOnFrameAvailableListener { sl.frame.set(true); queue.offer(1) }
            return sl
        }

        private fun makePlayer(sl: Slot, u: Uri): MediaPlayer? {
            val m = MediaPlayer()
            return try {
                m.setSurface(sl.surf)
                m.setDataSource(ctx, u)
                m.setOnCompletionListener { onDone(it) }
                m.setOnErrorListener { _, what, extra ->
                    onError("pemutar error $what/$extra")
                    val t = SystemClock.uptimeMillis()
                    if (t - lastRecoverMs > 2000) { lastRecoverMs = t; recoverN++; pending = curUri; queue.offer(1) }
                    true
                }
                m.prepare()
                m
            } catch (e: Exception) {
                android.util.Log.e("VideoWallpaper", "load error", e)
                onError("video: " + e)
                try { m.release() } catch (_: Exception) {}
                null
            }
        }

        // Pindah ke pemutar cadangan yang sudah siap di frame pertama (tanpa jeda).
        private fun swap() {
            synchronized(pl) {
                val sa = slot(act)
                val sb = slot(1 - act)
                val a = sa.player
                val b = sb.player
                val c = cfg
                try {
                    if (b == null) {
                        a?.seekTo(c.trimStart * 1000)
                        if (play) a?.start()
                    } else {
                        val v = if (c.sound) 1f else 0f
                        b.setVolume(v, v)
                        if (play) {
                            b.start()
                            if (sb.speed != c.speed) {
                                b.playbackParams = PlaybackParams().setSpeed(c.speed)
                                sb.speed = c.speed
                            }
                        }
                        a?.setVolume(0f, 0f)
                        a?.pause()
                        a?.seekTo(c.trimStart * 1000)
                        act = 1 - act
                    }
                } catch (_: Exception) {}
            }
        }

        private fun onDone(m: MediaPlayer) {
            synchronized(pl) { if (play && m === slot(act).player) swap() }
        }

        // Hanya menyentuh pemutar kalau memang ada yang berubah (menghindari tersendat).
        private fun applyCfg(fresh: Boolean) {
            synchronized(pl) {
                val sa = slot(act)
                val sb = slot(1 - act)
                val a = sa.player ?: return
                val b = sb.player
                try {
                    val c = cfg
                    val v = if (c.sound) 1f else 0f
                    a.isLooping = b == null && c.trimStart == 0 && c.trimEnd == 0 && !videoShort
                    a.setVolume(v, v)
                    if (b != null) { b.isLooping = false; b.setVolume(0f, 0f) }
                    if (fresh) {
                        a.seekTo(c.trimStart * 1000)
                        if (b != null) {
                            // siapkan pemutar cadangan: decode satu frame lalu kembali ke awal
                            b.start(); b.pause(); b.seekTo(c.trimStart * 1000)
                        }
                    }
                    if (play) {
                        if (!a.isPlaying) a.start()
                        if (sa.speed != c.speed) {
                            a.playbackParams = PlaybackParams().setSpeed(c.speed)
                            sa.speed = c.speed
                        }
                    } else if (fresh) {
                        a.start(); a.pause()
                    } else if (a.isPlaying) {
                        a.pause()
                    }
                } catch (_: Exception) {}
            }
        }

        // Durasi trek VIDEO saja. Kalau audio lebih panjang dari video, pemutar baru mengulang
        // setelah audio habis dan gambar membeku di frame terakhir selama selisihnya.
        private fun videoDurationMs(u: Uri): Int {
            val ex = MediaExtractor()
            return try {
                ex.setDataSource(ctx, u, null)
                var d = 0L
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_DURATION)) {
                        d = f.getLong(MediaFormat.KEY_DURATION) / 1000
                    }
                }
                d.toInt()
            } catch (e: Exception) { 0 } finally { try { ex.release() } catch (_: Exception) {} }
        }

        private fun loadVideo(u: Uri) {
            curUri = u
            loadedAtMs = SystemClock.uptimeMillis()
            synchronized(pl) {
                for (i in 0..1) {
                    val sl = slot(i)
                    try { sl.player?.release() } catch (_: Exception) {}
                    sl.player = null
                    sl.speed = -1f
                    sl.ts = -1L
                }
            }
            lastFrameMs = 0L
            val a = makePlayer(slot(0), u) ?: return
            val b = if (cfg.gapless) makePlayer(slot(1), u) else null
            if (a.videoHeight > 0) vAspect = a.videoWidth.toFloat() / a.videoHeight
            containerMs = try { a.duration } catch (_: Exception) { 0 }
            val vd = videoDurationMs(u)
            durMs = if (vd in 1 until containerMs) vd else containerMs
            videoShort = durMs in 1 until (containerMs - 300)
            synchronized(pl) {
                slot(0).player = a
                slot(1).player = b
                act = 0
            }
            applyCfg(true)
            loadedAtMs = SystemClock.uptimeMillis()
        }

        override fun run() {
            var display = EGL14.EGL_NO_DISPLAY
            var eglCtx = EGL14.EGL_NO_CONTEXT
            var eglSurf = EGL14.EGL_NO_SURFACE
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY)
                display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                val ver = IntArray(2)
                EGL14.eglInitialize(display, ver, 0, ver, 1)
                val attr = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
                )
                val cfgs = arrayOfNulls<EGLConfig>(1)
                val n = IntArray(1)
                EGL14.eglChooseConfig(display, attr, 0, cfgs, 0, 1, n, 0)
                val eglCfg = cfgs[0] ?: return
                eglCtx = EGL14.eglCreateContext(
                    display, eglCfg, EGL14.EGL_NO_CONTEXT,
                    intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
                )
                eglSurf = EGL14.eglCreateWindowSurface(display, eglCfg, holder.surface, intArrayOf(EGL14.EGL_NONE), 0)
                EGL14.eglMakeCurrent(display, eglSurf, eglSurf, eglCtx)
                EGL14.eglSwapInterval(display, 1)

                val vs = shader(GLES20.GL_VERTEX_SHADER, """
                    attribute vec4 aPos; attribute vec2 aTex;
                    uniform mat4 uST; uniform vec4 uCrop;
                    varying vec2 vTex;
                    void main() {
                        gl_Position = aPos;
                        vec2 t = vec2(uCrop.x + aTex.x * uCrop.z, uCrop.y + aTex.y * uCrop.w);
                        vTex = (uST * vec4(t, 0.0, 1.0)).xy;
                    }""")
                val fs = shader(GLES20.GL_FRAGMENT_SHADER, """
                    #extension GL_OES_EGL_image_external : require
                    precision mediump float;
                    varying vec2 vTex;
                    uniform samplerExternalOES uTex;
                    uniform float uDim;
                    void main() { gl_FragColor = vec4(texture2D(uTex, vTex).rgb * uDim, 1.0); }""")
                val prog = GLES20.glCreateProgram()
                GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs)
                GLES20.glLinkProgram(prog)
                val aPos = GLES20.glGetAttribLocation(prog, "aPos")
                val aTex = GLES20.glGetAttribLocation(prog, "aTex")
                val uST = GLES20.glGetUniformLocation(prog, "uST")
                val uCrop = GLES20.glGetUniformLocation(prog, "uCrop")
                val uTex = GLES20.glGetUniformLocation(prog, "uTex")
                val uDim = GLES20.glGetUniformLocation(prog, "uDim")
                val pos = buf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                val tex = buf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

                s0 = newSlot()
                s1 = newSlot()
                if (useExo) onSurface(slot(0).surf)
                val sAspect = if (sh > 0) sw.toFloat() / sh else 0.5f
                var lastDrawNs = 0L
                var lastDrawnCur = -1f
                var lastAutoDim = 0

                while (running) {
                    var tgt = targetOffset()
                    if (abs(tgt - cur) < 0.00005f) {
                        if (play) queue.poll(40, TimeUnit.MILLISECONDS) else queue.take()
                        lastNs = System.nanoTime() - 16_000_000L
                        tgt = targetOffset()
                    }
                    queue.clear()
                    if (!running) break
                    val nowNs = System.nanoTime()
                    val dtMs = ((nowNs - lastNs) / 1_000_000f).coerceIn(1f, 50f)
                    lastNs = nowNs
                    cur += (tgt - cur) * (1f - exp(-dtMs / 70f))

                    val pu = pending
                    var force = pu != null
                    if (pu != null) { pending = null; loadVideo(pu) }
                    if (dirty) { dirty = false; applyCfg(false); force = true }
                    val ad = autoDim
                    if (ad != lastAutoDim) { lastAutoDim = ad; force = true }
                    val c = cfg

                    val nowMs0 = SystemClock.uptimeMillis()
                    if (lastIterMs != 0L && nowMs0 - lastIterMs > 1000) { lastFrameMs = 0L; loadedAtMs = nowMs0 }
                    lastIterMs = nowMs0
                    if (play && !wasPlay) { loadedAtMs = nowMs0; lastFrameMs = 0L }
                    wasPlay = play
                    if (play && lastFrameMs != 0L && nowMs0 - lastFrameMs > 800 && nowMs0 - lastSoftMs > 2500) {
                        // gambar diam padahal seharusnya jalan: paksa mengulang dari awal
                        lastSoftMs = nowMs0
                        softN++
                        onStat("$stallMax,$stallN,$recoverN,$softN")
                        synchronized(pl) {
                            try {
                                val p = slot(act).player
                                if (p != null && p.currentPosition > 500) {
                                    if (slot(1 - act).player != null) swap() else p.seekTo(c.trimStart * 1000)
                                }
                            } catch (_: Exception) {}
                        }
                    }
                    if (play && curUri != null) {
                        val ref = if (lastFrameMs != 0L) lastFrameMs else loadedAtMs
                        if (nowMs0 - ref > 1500 && nowMs0 - lastRecoverMs > 4000) {
                            lastRecoverMs = nowMs0
                            recoverN++
                            onStat("$stallMax,$stallN,$recoverN,$softN")
                            pending = curUri
                            lastFrameMs = 0L
                            loadedAtMs = nowMs0
                        }
                    }

                    // Ambil SEMUA frame yang menunggu (bukan hanya satu), supaya decoder tidak macet.
                    var gotActive = false
                    for (i in 0..1) {
                        val sl = slot(i)
                        var k = 0
                        while (k < 4) {
                            sl.st.updateTexImage()
                            val ts = sl.st.timestamp
                            if (ts == sl.ts) break
                            sl.ts = ts
                            sl.has = true
                            if (i == act) gotActive = true
                            k++
                        }
                        if (k > 0) sl.st.getTransformMatrix(sl.m)
                    }
                    val prevDraw = drawIdx
                    if (slot(act).has) drawIdx = act
                    val need = force || gotActive || c.autoPan || drawIdx != prevDraw ||
                        abs(cur - lastDrawnCur) >= 0.0001f

                    if (!play) lastFrameMs = 0L
                    if (gotActive && play) {
                        val nowMs = SystemClock.uptimeMillis()
                        if (lastFrameMs != 0L) {
                            val gap = nowMs - lastFrameMs
                            if (gap > 150) {
                                stallN++
                                if (gap > stallMax) stallMax = gap
                                onStat("$stallMax,$stallN,$recoverN,$softN")
                            }
                        }
                        lastFrameMs = nowMs
                    }
                    if (gotActive && play && nowNs - lastPosNs > 50_000_000L) synchronized(pl) {
                        lastPosNs = nowNs
                        try {
                            val p = slot(act).player
                            if (p != null) {
                                val startMs = c.trimStart * 1000
                                val endMs = if (c.trimEnd > 0) minOf(c.trimEnd * 1000, durMs) else durMs
                                val pos = p.currentPosition
                                if (slot(1 - act).player != null) {
                                    if (endMs - startMs > 800 && pos >= endMs - 150) swap()
                                } else if ((c.trimEnd > 0 || videoShort) && pos >= endMs - 50) {
                                    p.seekTo(startMs)
                                }
                            }
                        } catch (_: Exception) {}
                    }

                    val ds = slot(drawIdx)
                    if (!ds.has) continue
                    if (!need) continue
                    if (c.fpsCap > 0 && !force && abs(cur - lastDrawnCur) < 0.0001f &&
                        nowNs - lastDrawNs < 1_000_000_000L / c.fpsCap - 3_000_000L) continue
                    lastDrawNs = nowNs
                    lastDrawnCur = cur
                    val off = if (c.autoPan) 0.5f + 0.5f * sin(SystemClock.uptimeMillis() / 4800.0).toFloat()
                              else cur.coerceIn(0f, 1f)
                    if (extAspect > 0f) vAspect = extAspect
                    var u0 = 0f; var v0 = 0f; var us = 1f; var vsc = 1f
                    if (vAspect > sAspect) { us = sAspect / vAspect; u0 = off * (1f - us) }
                    else { vsc = vAspect / sAspect; v0 = (1f - vsc) / 2f }
                    GLES20.glViewport(0, 0, sw, sh)
                    GLES20.glUseProgram(prog)
                    GLES20.glUniformMatrix4fv(uST, 1, false, ds.m, 0)
                    GLES20.glUniform4f(uCrop, u0, v0, us, vsc)
                    GLES20.glUniform1f(uDim, 1f - (c.dim + autoDim).coerceAtMost(90) / 100f)
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ds.tex)
                    GLES20.glUniform1i(uTex, 0)
                    GLES20.glEnableVertexAttribArray(aPos)
                    GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, pos)
                    GLES20.glEnableVertexAttribArray(aTex)
                    GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 8, tex)
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                    val t0 = System.nanoTime()
                    EGL14.eglSwapBuffers(display, eglSurf)
                    if (System.nanoTime() - t0 < 3_000_000L && abs(targetOffset() - cur) > 0.0004f) Thread.sleep(8)
                }
            } catch (e: Throwable) {
                android.util.Log.e("VideoWallpaper", "error", e)
                onError("GL: " + e + " @ " + e.stackTrace.firstOrNull())
            } finally {
                synchronized(pl) {
                    for (sl in listOf(s0, s1)) {
                        try { sl?.player?.release() } catch (_: Exception) {}
                        sl?.player = null
                    }
                }
                for (sl in listOf(s0, s1)) {
                    try { sl?.st?.release() } catch (_: Exception) {}
                    try { sl?.surf?.release() } catch (_: Exception) {}
                }
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (eglSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurf)
                    if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglCtx)
                    EGL14.eglTerminate(display)
                }
            }
        }
    }
}
