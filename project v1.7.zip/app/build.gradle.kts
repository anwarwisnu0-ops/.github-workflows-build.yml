plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.scrollvideo"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.scrollvideo"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
