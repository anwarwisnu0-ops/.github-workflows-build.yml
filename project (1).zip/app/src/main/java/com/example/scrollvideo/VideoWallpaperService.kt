package com.example.scrollvideo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sin

data class Cfg(
    val sound: Boolean, val speed: Float, val autoPan: Boolean,
    val dim: Int, val trimStart: Int, val trimEnd: Int
)

class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {
        private var thread: GlThread? = null
        private var holder: SurfaceHolder? = null
        private var w = 0
        private var h = 0
        private var offset = 0.5f
        private var visible = false
        private var videos: List<Uri> = emptyList()
        private var index = 0
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPref(key) }
        private val power = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refreshPlay() }
        }
        private val ticker = object : Runnable {
            override fun run() { nextVideo(); schedule() }
        }

        private fun onPref(key: String?) {
            when (key) {
                "videos" -> { loadList(); restart() }
                "interval" -> schedule()
                "pause_hidden", "bat_min" -> refreshPlay()
                else -> thread?.setCfg(readCfg())
            }
        }

        private fun readCfg() = Cfg(
            prefs.getBoolean("sound", false), prefs.getFloat("speed", 1f),
            prefs.getBoolean("auto_pan", false), prefs.getInt("dim", 0),
            prefs.getInt("trim_start", 0), prefs.getInt("trim_end", 0)
        )

        private fun loadList() {
            val raw = prefs.getString("videos", null) ?: prefs.getString("video", null) ?: ""
            videos = raw.split("\n").filter { it.isNotBlank() }.map { Uri.parse(it) }
            index = 0
        }

        private fun batteryOk(): Boolean {
            val min = prefs.getInt("bat_min", 0)
            if (min == 0) return true
            val pm = getSystemService(PowerManager::class.java)
            if (pm != null && pm.isPowerSaveMode) return false
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return true
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) * 100 / scale
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            return plugged || level >= min
        }

        private fun screenOn() = getSystemService(PowerManager::class.java)?.isInteractive ?: true
        private fun shouldPlay() = screenOn() && (visible || !prefs.getBoolean("pause_hidden", false)) && batteryOk()
        private fun refreshPlay() { thread?.setPlaying(shouldPlay()) }

        private fun schedule() {
            handler.removeCallbacks(ticker)
            val m = prefs.getInt("interval", 0)
            if (m > 0) handler.postDelayed(ticker, m * 60_000L)
        }

        private fun nextVideo() {
            if (videos.size < 2) return
            index = (index + 1) % videos.size
            thread?.setNext(videos[index])
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(listener)
            loadList()
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(power, f)
            schedule()
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            handler.removeCallbacks(ticker)
            try { unregisterReceiver(power) } catch (_: Exception) {}
            stopThread()
            super.onDestroy()
        }

        override fun onSurfaceChanged(sh: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(sh, format, width, height)
            holder = sh; w = width; h = height
            restart()
        }

        override fun onSurfaceDestroyed(sh: SurfaceHolder) {
            stopThread()
            holder = null
            super.onSurfaceDestroyed(sh)
        }

        override fun onVisibilityChanged(v: Boolean) {
            val was = visible
            visible = v
            if (v && !was && prefs.getInt("interval", 0) == -1) nextVideo()
            refreshPlay()
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int
        ) {
            offset = xOffset
            thread?.setOffset(xOffset)
        }

        private fun stopThread() {
            thread?.let { it.finish(); try { it.join(1500) } catch (_: Exception) {} }
            thread = null
        }

        private fun restart() {
            stopThread()
            val sh = holder ?: return
            if (videos.isEmpty()) return
            thread = GlThread(applicationContext, sh, w, h, videos[index.coerceIn(0, videos.size - 1)], readCfg(), offset).also {
                it.setPlaying(shouldPlay())
                it.start()
            }
        }
    }

    private class GlThread(
        val ctx: Context, val holder: SurfaceHolder, val sw: Int, val sh: Int,
        firstUri: Uri, startCfg: Cfg, startOffset: Float
    ) : Thread("video-wallpaper-gl") {
        private val queue = LinkedBlockingQueue<Int>().also { it.offer(1) }
        private val frameReady = AtomicBoolean(false)
        private val pl = Any()
        @Volatile private var running = true
        @Volatile private var dirty = false
        @Volatile private var offset = startOffset
        @Volatile private var cfg = startCfg
        @Volatile private var play = false
        @Volatile private var pending: Uri? = firstUri
        private var player: MediaPlayer? = null
        private var surf: Surface? = null
        private var vAspect = 16f / 9f

        fun setOffset(o: Float) { offset = o; queue.offer(1) }
        fun setPlaying(p: Boolean) { play = p; dirty = true; queue.offer(1) }
        fun setCfg(c: Cfg) { cfg = c; dirty = true; queue.offer(1) }
        fun setNext(u: Uri) { pending = u; queue.offer(1) }
        fun finish() { running = false; queue.offer(1) }

        private fun buf(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(a); position(0) }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
            return s
        }

        private fun restartTrim(m: MediaPlayer) {
            synchronized(pl) {
                if (m !== player) return
                try {
                    val s = cfg.trimStart * 1000
                    m.seekTo(if (s < m.duration) s else 0)
                    if (play) m.start()
                } catch (_: Exception) {}
            }
        }

        private fun applyCfg(fresh: Boolean) {
            synchronized(pl) {
                val m = player ?: return
                try {
                    val c = cfg
                    m.isLooping = c.trimStart == 0 && c.trimEnd == 0
                    val v = if (c.sound) 1f else 0f
                    m.setVolume(v, v)
                    if (fresh && c.trimStart > 0) m.seekTo(c.trimStart * 1000)
                    if (play) {
                        m.start()
                        m.playbackParams = PlaybackParams().setSpeed(c.speed)
                    } else if (fresh) {
                        m.start(); m.pause()
                    } else if (m.isPlaying) {
                        m.pause()
                    }
                } catch (_: Exception) {}
            }
        }

        private fun loadVideo(u: Uri) {
            synchronized(pl) {
                try { player?.release() } catch (_: Exception) {}
                player = null
            }
            val m = MediaPlayer()
            try {
                m.setSurface(surf)
                m.setDataSource(ctx, u)
                m.setOnCompletionListener { restartTrim(it) }
                m.prepare()
            } catch (e: Exception) {
                android.util.Log.e("VideoWallpaper", "load error", e)
                try { m.release() } catch (_: Exception) {}
                return
            }
            if (m.videoHeight > 0) vAspect = m.videoWidth.toFloat() / m.videoHeight
            synchronized(pl) { player = m }
            applyCfg(true)
        }

        override fun run() {
            var display = EGL14.EGL_NO_DISPLAY
            var eglCtx = EGL14.EGL_NO_CONTEXT
            var eglSurf = EGL14.EGL_NO_SURFACE
            var st: SurfaceTexture? = null
            try {
                display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                val ver = IntArray(2)
                EGL14.eglInitialize(display, ver, 0, ver, 1)
                val attr = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
                )
                val cfgs = arrayOfNulls<EGLConfig>(1)
                val n = IntArray(1)
                EGL14.eglChooseConfig(display, attr, 0, cfgs, 0, 1, n, 0)
                val eglCfg = cfgs[0] ?: return
                eglCtx = EGL14.eglCreateContext(
                    display, eglCfg, EGL14.EGL_NO_CONTEXT,
                    intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
                )
                eglSurf = EGL14.eglCreateWindowSurface(display, eglCfg, holder.surface, intArrayOf(EGL14.EGL_NONE), 0)
                EGL14.eglMakeCurrent(display, eglSurf, eglSurf, eglCtx)

                val vs = shader(GLES20.GL_VERTEX_SHADER, """
                    attribute vec4 aPos; attribute vec2 aTex;
                    uniform mat4 uST; uniform vec4 uCrop;
                    varying vec2 vTex;
                    void main() {
                        gl_Position = aPos;
                        vec2 t = vec2(uCrop.x + aTex.x * uCrop.z, uCrop.y + aTex.y * uCrop.w);
                        vTex = (uST * vec4(t, 0.0, 1.0)).xy;
                    }""")
                val fs = shader(GLES20.GL_FRAGMENT_SHADER, """
                    #extension GL_OES_EGL_image_external : require
                    precision mediump float;
                    varying vec2 vTex;
                    uniform samplerExternalOES uTex;
                    uniform float uDim;
                    void main() { gl_FragColor = vec4(texture2D(uTex, vTex).rgb * uDim, 1.0); }""")
                val prog = GLES20.glCreateProgram()
                GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs)
                GLES20.glLinkProgram(prog)
                val aPos = GLES20.glGetAttribLocation(prog, "aPos")
                val aTex = GLES20.glGetAttribLocation(prog, "aTex")
                val uST = GLES20.glGetUniformLocation(prog, "uST")
                val uCrop = GLES20.glGetUniformLocation(prog, "uCrop")
                val uTex = GLES20.glGetUniformLocation(prog, "uTex")
                val uDim = GLES20.glGetUniformLocation(prog, "uDim")
                val pos = buf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                val tex = buf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

                val ids = IntArray(1)
                GLES20.glGenTextures(1, ids, 0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

                st = SurfaceTexture(ids[0])
                st.setOnFrameAvailableListener { frameReady.set(true); queue.offer(1) }
                surf = Surface(st)

                val sAspect = if (sh > 0) sw.toFloat() / sh else 0.5f
                val m = FloatArray(16)
                var hasFrame = false
                while (running) {
                    queue.take(); queue.clear()
                    if (!running) break
                    val pu = pending
                    if (pu != null) { pending = null; loadVideo(pu) }
                    if (dirty) { dirty = false; applyCfg(false) }
                    val c = cfg
                    if (frameReady.getAndSet(false)) {
                        st.updateTexImage(); st.getTransformMatrix(m); hasFrame = true
                        if (c.trimEnd > 0) synchronized(pl) {
                            try {
                                val p = player
                                if (p != null && p.currentPosition >= c.trimEnd * 1000) p.seekTo(c.trimStart * 1000)
                            } catch (_: Exception) {}
                        }
                    }
                    if (!hasFrame) continue
                    val off = if (c.autoPan) 0.5f + 0.5f * sin(SystemClock.uptimeMillis() / 4800.0).toFloat()
                              else offset.coerceIn(0f, 1f)
                    var u0 = 0f; var v0 = 0f; var us = 1f; var vsc = 1f
                    if (vAspect > sAspect) { us = sAspect / vAspect; u0 = off * (1f - us) }
                    else { vsc = vAspect / sAspect; v0 = (1f - vsc) / 2f }
                    GLES20.glViewport(0, 0, sw, sh)
                    GLES20.glUseProgram(prog)
                    GLES20.glUniformMatrix4fv(uST, 1, false, m, 0)
                    GLES20.glUniform4f(uCrop, u0, v0, us, vsc)
                    GLES20.glUniform1f(uDim, 1f - c.dim / 100f)
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
                    GLES20.glUniform1i(uTex, 0)
                    GLES20.glEnableVertexAttribArray(aPos)
                    GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, pos)
                    GLES20.glEnableVertexAttribArray(aTex)
                    GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 8, tex)
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                    EGL14.eglSwapBuffers(display, eglSurf)
                }
            } catch (e: Exception) {
                android.util.Log.e("VideoWallpaper", "error", e)
            } finally {
                synchronized(pl) {
                    try { player?.release() } catch (_: Exception) {}
                    player = null
                }
                try { st?.release() } catch (_: Exception) {}
                try { surf?.release() } catch (_: Exception) {}
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (eglSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurf)
                    if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglCtx)
                    EGL14.eglTerminate(display)
                }
            }
        }
    }
}
