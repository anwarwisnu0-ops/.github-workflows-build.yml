package com.example.scrollvideo

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private val bg = Color.parseColor("#0F1115")
    private val cardColor = Color.parseColor("#1A1D24")
    private val accent = Color.parseColor("#7C5CFF")
    private val muted = Color.parseColor("#9AA0AE")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun label(t: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun cardOf(title: String, vararg views: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(cardColor, 18)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        c.addView(label(title, 13f, accent, true))
        views.forEach { v ->
            c.addView(v, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        }
        return c
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE)
        background = box(if (primary) accent else Color.parseColor("#2A2E38"), 12)
        setOnClickListener { onClick() }
    }

    private fun toggle(t: String, key: String) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE)
        isChecked = prefs.getBoolean(key, false)
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun field(title: String, v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 13f, muted))
        addView(v)
    }

    private fun numField(hint: String, key: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        this.hint = hint
        setHintTextColor(muted); setTextColor(Color.WHITE)
        setText(prefs.getInt(key, 0).let { if (it == 0) "" else it.toString() })
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putInt(key, s.toString().toIntOrNull() ?: 0).apply()
            }
        })
    }

    private fun readList() =
        (prefs.getString("videos", null) ?: prefs.getString("video", null) ?: "")
            .split("\n").filter { it.isNotBlank() }

    private fun pickVideos(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, code)
    }

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, VideoWallpaperService::class.java)
        )
        try { startActivity(i) } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        status = label("", 17f, Color.WHITE, true)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Pilih video", false) { pickVideos(1) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(button("Tambah video", false) { pickVideos(2) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }

        val intervals = listOf(0, -1, 5, 15, 30, 60)
        val intervalSpin = spinner(
            listOf("Tidak ganti (ulang video yang sama)", "Tiap kembali ke layar utama",
                "Tiap 5 menit", "Tiap 15 menit", "Tiap 30 menit", "Tiap 1 jam"),
            intervals.indexOf(prefs.getInt("interval", 0)).coerceAtLeast(0)
        ) { prefs.edit().putInt("interval", intervals[it]).apply() }

        val speeds = listOf(0.5f, 0.75f, 1f, 1.5f, 2f)
        val speedSpin = spinner(
            listOf("0.5x (lambat)", "0.75x", "1x (normal)", "1.5x", "2x (cepat)"),
            speeds.indexOf(prefs.getFloat("speed", 1f)).let { if (it < 0) 2 else it }
        ) { prefs.edit().putFloat("speed", speeds[it]).apply() }

        val dimLabel = label("Gelapkan video: ${prefs.getInt("dim", 0)}%", 13f, muted)
        val dimSeek = SeekBar(this).apply {
            max = 80; progress = prefs.getInt("dim", 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    dimLabel.text = "Gelapkan video: $p%"
                    if (fromUser) prefs.edit().putInt("dim", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val panLabel = label("Kekuatan geser: ${prefs.getInt("pan_strength", 100)}%", 13f, muted)
        val panSeek = SeekBar(this).apply {
            max = 80; progress = prefs.getInt("pan_strength", 100) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    panLabel.text = "Kekuatan geser: ${p + 20}%"
                    if (fromUser) prefs.edit().putInt("pan_strength", p + 20).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val trimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(numField("Mulai (detik)", "trim_start"),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
            addView(numField("Selesai (0 = akhir)", "trim_end"),
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        }

        val bats = listOf(0, 15, 20, 30, 50)
        val batSpin = spinner(
            listOf("Mati", "Di bawah 15%", "Di bawah 20%", "Di bawah 30%", "Di bawah 50%"),
            bats.indexOf(prefs.getInt("bat_min", 0)).coerceAtLeast(0)
        ) { prefs.edit().putInt("bat_min", bats[it]).apply() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        root.addView(label("Scroll Video Wallpaper", 26f, Color.WHITE, true))
        root.addView(label("Video landscape jadi wallpaper yang ikut bergeser", 14f, muted),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4); bottomMargin = dp(8) })
        val cards = listOf(
            cardOf("VIDEO", status, row, button("Pasang sebagai wallpaper", true) { applyWallpaper() }),
            cardOf("PLAYLIST", field("Ganti video otomatis", intervalSpin)),
            cardOf("PEMUTARAN",
                toggle("Suara video", "sound"),
                toggle("Geser otomatis (tanpa perlu scroll)", "auto_pan"),
                field("Kecepatan", speedSpin),
                dimLabel, dimSeek, panLabel, panSeek,
                label("Potong bagian video yang diulang", 13f, muted), trimRow),
            cardOf("HEMAT BATERAI",
                toggle("Jeda saat aplikasi lain dibuka", "pause_hidden"),
                field("Berhenti otomatis kalau baterai", batSpin),
                label("Mode hemat daya sistem juga ikut menjeda video saat opsi baterai di atas aktif.", 12f, muted))
        )
        cards.forEach { root.addView(it, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }) }

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
        refresh()
    }

    private fun refresh() {
        val n = readList().size
        status.text = if (n == 0) "Belum ada video dipilih" else "$n video dipilih"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode != 1 && requestCode != 2) || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        uris.forEach {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        val old = if (requestCode == 2) readList() else emptyList()
        val all = (old + uris.map { it.toString() }).distinct().joinToString("\n")
        prefs.edit().putString("videos", all).apply()
        refresh()
    }
}
