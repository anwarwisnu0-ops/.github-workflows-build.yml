package com.example.scrollvideo

import android.content.Context
import android.content.SharedPreferences
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {
        private var thread: GlThread? = null
        private var holder: SurfaceHolder? = null
        private var w = 0
        private var h = 0
        private var offset = 0.5f
        private var visible = false
        private val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "video") restart() else thread?.setPlaying(shouldPlay())
        }

        private fun shouldPlay() = visible || !prefs.getBoolean("pause_hidden", false)

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(listener)
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            stopThread()
            super.onDestroy()
        }

        override fun onSurfaceChanged(sh: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(sh, format, width, height)
            holder = sh; w = width; h = height
            restart()
        }

        override fun onSurfaceDestroyed(sh: SurfaceHolder) {
            stopThread()
            holder = null
            super.onSurfaceDestroyed(sh)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            thread?.setPlaying(shouldPlay())
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPixels: Int, yPixels: Int
        ) {
            offset = xOffset
            thread?.setOffset(xOffset)
        }

        private fun stopThread() {
            thread?.let { it.finish(); try { it.join(1500) } catch (_: Exception) {} }
            thread = null
        }

        private fun restart() {
            stopThread()
            val sh = holder ?: return
            val uri = prefs.getString("video", null)?.let { Uri.parse(it) } ?: return
            thread = GlThread(applicationContext, sh, uri, w, h, offset).also {
                it.setPlaying(shouldPlay())
                it.start()
            }
        }
    }

    private class GlThread(
        val ctx: Context, val holder: SurfaceHolder, val uri: Uri,
        val sw: Int, val sh: Int, startOffset: Float
    ) : Thread("video-wallpaper-gl") {
        private val queue = LinkedBlockingQueue<Int>()
        private val frameReady = AtomicBoolean(false)
        @Volatile private var running = true
        @Volatile private var offset = startOffset
        @Volatile private var wantPlay = false
        @Volatile private var player: MediaPlayer? = null

        fun setOffset(o: Float) { offset = o; queue.offer(1) }
        fun setPlaying(p: Boolean) {
            wantPlay = p
            try { if (p) player?.start() else player?.pause() } catch (_: Exception) {}
        }
        fun finish() { running = false; queue.offer(1) }

        private fun buf(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(a); position(0) }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
            return s
        }

        override fun run() {
            var display = EGL14.EGL_NO_DISPLAY
            var eglCtx = EGL14.EGL_NO_CONTEXT
            var eglSurf = EGL14.EGL_NO_SURFACE
            var st: SurfaceTexture? = null
            var surf: Surface? = null
            var mp: MediaPlayer? = null
            try {
                display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                val ver = IntArray(2)
                EGL14.eglInitialize(display, ver, 0, ver, 1)
                val attr = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
                )
                val cfgs = arrayOfNulls<EGLConfig>(1)
                val n = IntArray(1)
                EGL14.eglChooseConfig(display, attr, 0, cfgs, 0, 1, n, 0)
                val cfg = cfgs[0] ?: return
                eglCtx = EGL14.eglCreateContext(
                    display, cfg, EGL14.EGL_NO_CONTEXT,
                    intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
                )
                eglSurf = EGL14.eglCreateWindowSurface(display, cfg, holder.surface, intArrayOf(EGL14.EGL_NONE), 0)
                EGL14.eglMakeCurrent(display, eglSurf, eglSurf, eglCtx)

                val vs = shader(GLES20.GL_VERTEX_SHADER, """
                    attribute vec4 aPos; attribute vec2 aTex;
                    uniform mat4 uST; uniform vec4 uCrop;
                    varying vec2 vTex;
                    void main() {
                        gl_Position = aPos;
                        vec2 t = vec2(uCrop.x + aTex.x * uCrop.z, uCrop.y + aTex.y * uCrop.w);
                        vTex = (uST * vec4(t, 0.0, 1.0)).xy;
                    }""")
                val fs = shader(GLES20.GL_FRAGMENT_SHADER, """
                    #extension GL_OES_EGL_image_external : require
                    precision mediump float;
                    varying vec2 vTex;
                    uniform samplerExternalOES uTex;
                    void main() { gl_FragColor = texture2D(uTex, vTex); }""")
                val prog = GLES20.glCreateProgram()
                GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs)
                GLES20.glLinkProgram(prog)
                val aPos = GLES20.glGetAttribLocation(prog, "aPos")
                val aTex = GLES20.glGetAttribLocation(prog, "aTex")
                val uST = GLES20.glGetUniformLocation(prog, "uST")
                val uCrop = GLES20.glGetUniformLocation(prog, "uCrop")
                val uTex = GLES20.glGetUniformLocation(prog, "uTex")
                val pos = buf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                val tex = buf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

                val ids = IntArray(1)
                GLES20.glGenTextures(1, ids, 0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

                st = SurfaceTexture(ids[0])
                st.setOnFrameAvailableListener { frameReady.set(true); queue.offer(1) }
                surf = Surface(st)
                mp = MediaPlayer().apply {
                    setSurface(surf)
                    setDataSource(ctx, uri)
                    isLooping = true
                    setVolume(0f, 0f)
                    prepare()
                }
                player = mp
                val vAspect = if (mp.videoHeight > 0) mp.videoWidth.toFloat() / mp.videoHeight else 16f / 9f
                val sAspect = if (sh > 0) sw.toFloat() / sh else 0.5f
                mp.start()
                if (!wantPlay) mp.pause()

                val m = FloatArray(16)
                var hasFrame = false
                while (running) {
                    queue.take(); queue.clear()
                    if (!running) break
                    if (frameReady.getAndSet(false)) {
                        st.updateTexImage(); st.getTransformMatrix(m); hasFrame = true
                    }
                    if (!hasFrame) continue
                    var u0 = 0f; var v0 = 0f; var us = 1f; var vsc = 1f
                    if (vAspect > sAspect) { us = sAspect / vAspect; u0 = offset.coerceIn(0f, 1f) * (1f - us) }
                    else { vsc = vAspect / sAspect; v0 = (1f - vsc) / 2f }
                    GLES20.glViewport(0, 0, sw, sh)
                    GLES20.glUseProgram(prog)
                    GLES20.glUniformMatrix4fv(uST, 1, false, m, 0)
                    GLES20.glUniform4f(uCrop, u0, v0, us, vsc)
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, ids[0])
                    GLES20.glUniform1i(uTex, 0)
                    GLES20.glEnableVertexAttribArray(aPos)
                    GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, pos)
                    GLES20.glEnableVertexAttribArray(aTex)
                    GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 8, tex)
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                    EGL14.eglSwapBuffers(display, eglSurf)
                }
            } catch (e: Exception) {
                android.util.Log.e("VideoWallpaper", "error", e)
            } finally {
                player = null
                try { mp?.release() } catch (_: Exception) {}
                try { st?.release() } catch (_: Exception) {}
                try { surf?.release() } catch (_: Exception) {}
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (eglSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurf)
                    if (eglCtx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglCtx)
                    EGL14.eglTerminate(display)
                }
            }
        }
    }
}
